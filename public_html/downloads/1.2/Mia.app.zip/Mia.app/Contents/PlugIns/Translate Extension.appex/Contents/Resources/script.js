document.addEventListener("contextmenu", handleContextMenu, false);
function handleContextMenu(event) {
    var selectedText = window.getSelection().toString();
    var url = document.URL;
    safari.extension.setContextMenuEventUserInfo(event, { "selectedText": selectedText, "url": url });
}
